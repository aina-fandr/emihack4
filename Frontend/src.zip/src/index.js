import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';  // ← Assurez-vous que c'est 'App' sans extension

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);